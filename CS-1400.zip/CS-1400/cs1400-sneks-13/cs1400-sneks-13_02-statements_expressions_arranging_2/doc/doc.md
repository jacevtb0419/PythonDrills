# 13.2) Arranging More Statements

Here is a complete program whose statements depend on each other but are
currently in the wrong order. Arrange them in such a way that the program
executes as intended by printing the correct result.

If you need to reset your program, replace your Python file with the one with
the same name in the starter folder.
