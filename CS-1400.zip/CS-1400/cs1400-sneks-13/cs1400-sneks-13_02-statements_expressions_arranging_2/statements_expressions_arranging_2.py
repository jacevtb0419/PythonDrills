print(e)
f = b < c
e = f or a
d = b * c
c = 7
b = c * 5
a = b * c > d



c = 7
b = c * 5
d = b * c 
f = b < c
a = b * c > d
e = f or a
print(e)