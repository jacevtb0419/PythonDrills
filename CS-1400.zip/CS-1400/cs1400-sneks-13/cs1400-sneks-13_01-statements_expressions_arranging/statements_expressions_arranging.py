left_width = 5
right_width = 5
height = 10
total_cost = 100
width = left_width + right_width
area = (width * height)
print(area / total_cost)
