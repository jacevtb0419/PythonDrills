# 14.3) Type Errors

The provided program has an error. Run the program, read the error message, and
fix the problem so that the code correctly prints "The Number 5".

Note: You cannot simply delete the addition.
