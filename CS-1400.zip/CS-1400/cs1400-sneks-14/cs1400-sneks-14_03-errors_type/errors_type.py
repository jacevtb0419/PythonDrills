print("The Number" + " 5")
