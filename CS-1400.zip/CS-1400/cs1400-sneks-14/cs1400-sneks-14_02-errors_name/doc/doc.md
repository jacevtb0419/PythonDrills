# 14.2) Name Errors

The provided program has an error. Run the program, read the error message, and
fix the problem so that the code correctly prints "Hello World".
