message = "Hello World"
print(message)

