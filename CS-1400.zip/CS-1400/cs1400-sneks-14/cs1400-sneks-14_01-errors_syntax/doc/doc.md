# 14.1) Syntax Errors

The provided program has an error. Run the program, read the error message, and
fix the problem so that the code correctly prints "Hello World".

Hint: you may want to review the term "EOF".
