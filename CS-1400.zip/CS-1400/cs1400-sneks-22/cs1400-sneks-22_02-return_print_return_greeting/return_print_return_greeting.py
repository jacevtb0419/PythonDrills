from cisc108 import assert_equal
def return_greeting(name):
    return "Hello " + name
assert_equal(return_greeting("Bruce Wayne"), "Hello Bruce Wayne")