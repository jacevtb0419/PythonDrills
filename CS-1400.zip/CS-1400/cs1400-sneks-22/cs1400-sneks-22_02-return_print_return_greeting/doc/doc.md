# 22.2) Return greetting

Write a function `return_greeting` that consumes a name (as a string value) and
returns `Hello X`, where `X` is the given name. So for example, if the name
`"Bruce Wayne"` was passed in, the function should return `Hello Bruce Wayne`.
Unit test the function.

In other words, do the same thing as the previous problem except this time the
function returns instead of printing.
