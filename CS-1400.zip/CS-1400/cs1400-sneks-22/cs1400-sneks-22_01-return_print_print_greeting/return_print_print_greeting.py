from cisc108 import assert_equal
def print_greeting(name):
    print("Hello " + name) 

assert_equal(print_greeting("Bruce Wayne"), None)

