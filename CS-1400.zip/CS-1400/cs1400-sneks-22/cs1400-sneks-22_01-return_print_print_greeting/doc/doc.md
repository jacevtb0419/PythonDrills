# 22.1) Print greeting

Write a function `print_greeting` that consumes a name (as a string value) and
prints out `Hello X`, where `X` is the given name. So for example, if the name
`"Bruce Wayne"` was passed in, the function should print `Hello Bruce Wayne`.

Write at least one unit test, but consider carefully what the function should
return; you should not explicitly be returning anything - so what is returned by
default?
