# 22.4) Body Problem

The given function definition is correctly named and has two parameters, but has
an issue with its body. Fix the issue so that it will return the correct result
when it is called. Hint: the issue does not cause an error, it just prevents the
tests from passing.
