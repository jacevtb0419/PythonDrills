# 9.3) Multiplication

Using the `*` operator, print out the result of `24*365` (which will roughly
represent the number of hours in a year). Do not embed the result in your code.
Let Python do the calculation for you.
