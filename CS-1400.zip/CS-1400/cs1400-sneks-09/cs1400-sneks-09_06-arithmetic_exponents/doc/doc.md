# 9.6) Exponents

Using the `**` operator, print out the result of `2**10` (which is the size of a
kilobyte, a common unit of measurement in computers). Do not embed the result in
your code. Let Python do the calculation for you.
