# 9.5) Modulo

Using the `%` (modulo) operator, print out the result of `23%12` (which will
convert "2300 hours" from military time to the regular 12-hour clock time). Do
not embed the result in your code. Let Python do the calculation for you.
