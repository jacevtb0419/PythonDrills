# 9.2) Subtraction

Using the `-` operator, print out the result of `15-2` (which will represent the
number of weeks left in this semester). Do not embed the result in your code.
Let Python do the calculation for you.
