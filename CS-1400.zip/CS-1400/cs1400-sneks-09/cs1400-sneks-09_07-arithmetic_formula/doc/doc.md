# 9.7) A Formula

Because computers are very good at doing math, we won't have to worry about
doing much math in this course. In fact, learning how to program is actually
more similar to learning a new language! Regardless, it's good to remember how
to do a little math. For this exercise, you will print out the result of one
more calculation. This time convert the temperature 50° Fahrenheit to Celsius
using the following conversion formula:

``celsius = (fahrenheit - 32) * 5/9``

Remember, you should not embed the result directly into your code. You must
print out the result of this calculation.
