# 9.1) Addition

Using the + operator, write an expression to print out the result of 5+2 (which
will represent the number of days in a week, as the combination of weekdays and
the weekend). Do not embed the result in your code. Let Python do the
calculation for you.
