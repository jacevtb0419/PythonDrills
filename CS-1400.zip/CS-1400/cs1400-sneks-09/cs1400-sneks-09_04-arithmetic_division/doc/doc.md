# 9.4) Division

Using the `/` operator, print out the result of `10000/212` (which will
represent the average number of students per faculty at DSU). Do not embed the
result in your code. Let Python do the calculation for you.
