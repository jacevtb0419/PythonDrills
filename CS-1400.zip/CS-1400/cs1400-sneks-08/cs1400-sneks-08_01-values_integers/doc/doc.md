# 8.1) Integers

We can use Python to represent information. Write a single integer literal that
represents your current age in years. Then, print that number.
