# 8.4) Booleans

We can use Python to represent information. Use a boolean literal to print
whether you think it will rain tomorrow (True for yes, False for no).
