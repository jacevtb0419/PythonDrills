# 8.3) Strings

We can use Python to represent information. Write a string literal to represent
and print your name. It's okay if you want to use a nickname instead!
