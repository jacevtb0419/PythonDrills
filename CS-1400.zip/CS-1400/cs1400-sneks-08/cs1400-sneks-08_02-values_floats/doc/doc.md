# 8.2) Floats

We can use Python to represent information. Write a float literal to represent
your *ideal* GPA (e.g., 4.00). Then, print that number.
