# 8.5) Numbers vs. Strings

When representing information in Python, you have a number of choices. Different
situations demand different data representations, even if the result seems
similar. To highlight this result, you should print two things. First, print the
year you were born as a number. Then, print the year you were born as a string.
Notice that the output is the same either way, but the two values are
represented in the code differently.
