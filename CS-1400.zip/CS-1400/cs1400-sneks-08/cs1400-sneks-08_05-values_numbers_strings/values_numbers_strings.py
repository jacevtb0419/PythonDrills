print(2002)
print("2002")