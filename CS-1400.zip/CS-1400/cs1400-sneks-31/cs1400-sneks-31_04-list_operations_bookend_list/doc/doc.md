# 31.4) Bookend List

Create a function `bookend_list` that consumes a list as a parameter and returns
the first and last elements of that list but as part of a new list. If the
original list is empty, return an empty list instead. Unit test this function
sufficiently.
