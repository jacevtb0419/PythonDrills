# 31.5) Membership Test

Assume that you are developing a system to process lists containing days of the
week, represented as strings. Create a function `is_weekend` that consumes such
a list and returns whether it has the string `"Saturday"` or the string
`"Sunday"` in it. Unit test this function with a list of days of the week.
