# 31.3) Last

Use list indexing to print the last element of the list literal value.

Do not store the list value into a temporary variable. The goal is to practice
indexing a list literal, primarily to show that it is possible.
