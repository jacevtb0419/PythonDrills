print(["Not me", "Nor me", "Print me!"][-1])
