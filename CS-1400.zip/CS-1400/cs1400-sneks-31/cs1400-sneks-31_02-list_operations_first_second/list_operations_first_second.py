temperatures = [50, 60, 55, 35, 50, 65]
print(temperatures[0])
print(temperatures[1])