# 31.2) First and Second

Use list indexing to print the first and second elements of the given list on
separate lines.
