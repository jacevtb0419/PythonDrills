# 31.1) Append

The list below is meant to represent the animals of a zoo, but it is currently
empty. Use the append method to add 3 new animals of your choice. Print the list
afterwards. Do not write a function.
