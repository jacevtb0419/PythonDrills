zoo = []
zoo.append("Lion")
zoo.append("Tiger")
zoo.append("Bear")
print(zoo)