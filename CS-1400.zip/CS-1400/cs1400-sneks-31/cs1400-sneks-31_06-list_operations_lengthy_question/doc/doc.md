# 31.6) Lengthy Question

The `len` function consumes a list and returns its length as an integer. Use the
`len` function to write your own function `check_length` that consumes a list
and returns whether it is between 3 and 5 items long, inclusive. Unit test your
function.
