# 30.2) Book List

Create a list of 3 strings that represent the names of your favorite books and
store it in a variable. Print this variable. Do not write a function, just
assign the list value to a variable and print it.
