# 30.3) Emptiness

Print an empty list literal value. That's it; just directly print the empty list
literal value.

Hint: don't make it more complicated than it needs to be :)
