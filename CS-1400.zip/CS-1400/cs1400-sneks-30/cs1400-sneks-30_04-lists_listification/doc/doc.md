# 30.4) Listification

Create a function `make_list` that consumes three elements and returns them as a
list. Unit test the function at least once.
