Calories = [470, 440, 1060]
print(Calories)