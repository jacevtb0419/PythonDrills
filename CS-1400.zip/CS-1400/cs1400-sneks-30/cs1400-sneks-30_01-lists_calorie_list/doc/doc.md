# 30.1) Calorie List

Create a list of 3 numbers that represent the calories of your favorite foods
and store it in a variable. Print this variable. Do not write a function, just
assign the list value to a variable and print it.

If you don't know the calorie counts off the top of your head, check this
website: https://www.calorieking.com/us/en/foods/
