# 33.3) Cube Elements

Use the Map pattern to create a function called `cube_elements` that consumes a
list of numbers and returns a new list of each number cubed (to the third
power). Unit test this function.
