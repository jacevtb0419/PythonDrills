pages_count_list = [223, 251, 317, 636]
sum_pages = 0
for count in pages_count_list:
    sum_pages = sum_pages + count
print (sum_pages)
