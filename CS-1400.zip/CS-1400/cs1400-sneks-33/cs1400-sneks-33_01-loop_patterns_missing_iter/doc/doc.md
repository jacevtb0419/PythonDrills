# 33.1) Missing Iter

The given program is intended to sum and print the number of pages in 4 books
from the first four Harry Potter books. Fill in the two blanks so that the
algorithm works correctly.
