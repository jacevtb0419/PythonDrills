# 33.4) Sum High

Use the Filter pattern to write a function `sum_high` that consumes a list of
numbers and returns the sum of only the numbers that are greater than 50 in the
list. Unit test this function.
