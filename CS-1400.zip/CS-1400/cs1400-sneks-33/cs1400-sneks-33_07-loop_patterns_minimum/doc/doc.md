# 33.7) Minimum

Use the Min/Max pattern to write a function called `minimum`. This function
consumes a non-empty list of numbers and returns the lowest number in the list.
Unit test this function.
