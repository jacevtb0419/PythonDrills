# 33.5) Filter High

Use the Filter pattern to write a function `filter_high` that consumes a list of
numbers and returns a new list without any numbers greater than 50. Unit test
this function.
