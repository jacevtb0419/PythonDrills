# 33.2) An Average Problem

Create a function named `average` that consumes a list of numbers
and returns their average (as a float) by combining the Sum
and Count patterns:

    average = sum / count

Unit test your function.
