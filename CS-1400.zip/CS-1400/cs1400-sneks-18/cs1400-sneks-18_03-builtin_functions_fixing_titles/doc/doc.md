# 18.3) Fixing Book Titles

The string in the given program was downloaded off the internet and has numerous
problems. Fix it by using methods you find in the String functions reference
page in Canvas.

For this drill you should:

1. Strip all spaces from the end,
2. replace all dashes with spaces,
3. title case the words, and then,
4. print the correctly formatted string.
