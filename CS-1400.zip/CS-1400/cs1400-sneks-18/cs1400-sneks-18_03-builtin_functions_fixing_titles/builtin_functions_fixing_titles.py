book = "  the-count-of-monte-cristo  "
print(book.strip().replace("-", " ").title() )