filename = "01 All The Single Ladies.mp3"
print(filename.replace(" ", "-"))