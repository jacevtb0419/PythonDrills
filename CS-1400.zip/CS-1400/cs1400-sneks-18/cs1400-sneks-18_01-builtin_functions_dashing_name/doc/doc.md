# 18.1) A Dashing Name

While organizing your MP3 collection, you discovered that some of your songs had
spaces in the names. You rush to fix this blight by writing a program to
replace all spaces in the filenames with the "-" symbol.

In this drill, you will simply use the `replace` function to fix and then print
the string value stored in the variable `filename` in the given program.

Refer to the String functions reference page in Canvas for more details about
how to use the `replace` function.
