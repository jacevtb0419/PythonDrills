# 18.2) Highs and Lows

Consider the scenario in which you, a software developer, are building a system
for analyzing rainfall. The string in the given program represents "High" and
"Low" days for the level of a river over the course of a week. Count and print
the number of "High" days that are in the string.

Using the String function reference page in Canvas, find a method to help you
solve this problem of counting the number of occurrences of one string inside of
another string.
