creek_rainfall = "High, High, Low, Low, High, High, Low"
print( creek_rainfall.count("High"))