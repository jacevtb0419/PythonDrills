message = "Why are you shouting?"
print(message.upper())
