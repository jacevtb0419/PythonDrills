# 18.5) What's in a name?

The given program has an error. Fix it so that the expression correctly makes
the string entirely uppercase.

You might want to review the String functions reference page in Canvas.
