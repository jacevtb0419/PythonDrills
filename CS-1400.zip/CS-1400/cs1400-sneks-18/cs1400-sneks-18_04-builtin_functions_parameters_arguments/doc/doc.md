# 18.4) Parameters vs. Arguments

The method call in the given program uses a parameter instead of an argument.
Replace the parameter with a possible value so that the expression evaluates to
`True`. The program should print that result.

Refer to the string functions documentation page in Canvas for more information
about the `endswith` method.

If you need to reset your program, replace your Python file with the one with
the same name in the starter folder.
