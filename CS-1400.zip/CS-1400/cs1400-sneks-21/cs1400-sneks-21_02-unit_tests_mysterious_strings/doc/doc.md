# 21.2) Mysterious Strings

This mysterious function has failed its unit test. It is supposed to consume a
string and then *print* some text. Based on the output of the unit tests,
diagnose what operation the function is SUPPOSED to be doing, and then fix it to
pass the unit tests.
