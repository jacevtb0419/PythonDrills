from cisc108 import assert_equal 
def mysterious_strings(a_string):
    return print(a_string[0] + a_string[-1])

assert_equal(mysterious_strings("Hello"), Ho)


mysterious_strings("Hello")
