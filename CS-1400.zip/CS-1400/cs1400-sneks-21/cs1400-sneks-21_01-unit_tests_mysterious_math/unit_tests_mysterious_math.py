from cisc108 import assert_equal

def mysterious_math(a, b):
    return a * b
assert_equal(mysterious_math(1, 2), 2)

print(mysterious_math(1, 2))
