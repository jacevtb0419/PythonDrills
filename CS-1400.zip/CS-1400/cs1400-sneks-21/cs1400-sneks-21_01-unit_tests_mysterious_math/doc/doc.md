# 21.1) Mysterious Math

This mysterious function has failed its unit tests. It is supposed to consume
two numbers, perform some operation, and then return the result. Run the Code
Grinder tests and, based on the output, diagnose what operation the function is
SUPPOSED to be performing. Then, fix the function so that it passes the unit
tests.
