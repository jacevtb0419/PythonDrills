# 21.4) Grading on a Curve

The formula below calculates a curved grade by applying a square root according
to the following formula:

`original_grade^.5 * 10`

Define a function named `curve_grade` that consumes a grade and uses the formula
to return the curved grade. Write at least three unit tests for the function to
confirm that it works.

Note: the formula above is not correct Python syntax. What is the proper Python
operator for the exponent operation?
