# 21.3) Be Polite

Create a function named `make_polite` that takes in a string named `message` and
returns it with `", please"` added to the end. Test the function by calling it
on the following messages: "Pet the dog" and "Walk the dog". Make sure you unit
test the function a suitable number of times!
