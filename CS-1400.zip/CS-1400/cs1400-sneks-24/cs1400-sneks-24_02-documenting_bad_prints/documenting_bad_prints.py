#print("First, we'll assign some variables.")
name = "Klaus"
title = "Dr."
age = 17
#print("Then, we'll join the string variables together.")
full_name = title + " " + name
#print("Next, we can join the name and age.")
full_message = full_name + "'s age is " + str(age)
#print("Then we will print out the result.")
print(full_message)
