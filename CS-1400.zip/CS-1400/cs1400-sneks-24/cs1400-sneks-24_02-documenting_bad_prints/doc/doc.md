# 24.2) Bad Prints

In the given program, comment out all of the `print` functions except for the
last one.
