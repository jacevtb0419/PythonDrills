# 24.3) Bad Body

Fix the given program so that the function is correctly documented. Or in other
words, move the docstring to its appropriate location so that the program can
function correctly.
