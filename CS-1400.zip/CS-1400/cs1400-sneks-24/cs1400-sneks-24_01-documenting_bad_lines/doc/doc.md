# 24.1) Bad Lines

Fix the given program so that the multiline comment does not cause a
SyntaxError.
