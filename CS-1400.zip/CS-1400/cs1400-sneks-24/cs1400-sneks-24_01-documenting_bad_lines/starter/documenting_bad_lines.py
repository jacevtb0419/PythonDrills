y = 7
x = 3
z = 2

result = y ** x + z * x    ''' This code is pretty
                               complicated. Basically,
                               we do some math and that
                               gives us the answer.'''
print(result)
