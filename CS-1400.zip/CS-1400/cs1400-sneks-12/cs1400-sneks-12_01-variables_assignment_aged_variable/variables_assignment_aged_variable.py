age = 22    
print(age)