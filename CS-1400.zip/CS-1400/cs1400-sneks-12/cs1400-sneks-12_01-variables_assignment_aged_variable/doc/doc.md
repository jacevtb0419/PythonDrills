# 12.1) A Finely Aged Variable

Assign an integer value that represents your age in years to a variable called
"age". Finally, print that value using your variable.
