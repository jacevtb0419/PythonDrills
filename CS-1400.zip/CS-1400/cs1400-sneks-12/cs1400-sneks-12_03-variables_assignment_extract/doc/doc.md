# 12.3) Extract Out a Variable

Change the given program so that it creates a new variable called "score" with the
value 103, and then print that new variable.
