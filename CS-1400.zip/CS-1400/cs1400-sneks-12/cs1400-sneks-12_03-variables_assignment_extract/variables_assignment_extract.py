score = 103
print(score)
