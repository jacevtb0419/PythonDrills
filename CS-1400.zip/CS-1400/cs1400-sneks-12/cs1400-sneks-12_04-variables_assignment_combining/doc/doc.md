# 12.4) Combining Variables

You recently went on a trip, and want to figure out your average speed. Create
two variables: one that represents the distance you traveled (432 miles) and one
that represents the time you spent traveling (6 hours). Then, write an
expression using those two variables to calculate your average miles per hour
and print the result.
