speed = 432
distance = 6
print(speed / distance)