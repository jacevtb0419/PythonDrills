# 12.2) What's In a Name Variable?

Assign a string value that represents your name to a variable, then, print this
variable. Do not just print your name directly. It's fine if you want to use a
nickname.
