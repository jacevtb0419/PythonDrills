nickname = "Christer" 
print(nickname)