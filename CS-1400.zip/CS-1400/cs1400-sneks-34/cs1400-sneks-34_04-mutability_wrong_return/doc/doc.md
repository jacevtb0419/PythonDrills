# 34.4) Wrong Return

The function `get_front_of_weekdays` consumes a string representing a day of the
week, and returns "weekend" if it is a Sunday or Saturday, or returns the day
without the "day" part at the end. However, it does not seem to be returning the
right values. Diagnose the issue and fix the function.
