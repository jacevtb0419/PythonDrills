# 34.3) Repeat, Louder

The function in the given program called `make_exclamations` is supposed to
consume a list of messages and return a new list of messages with exclamations
at the end ("!"). The function is defined and called twice, but run the function
and you will see that it seems to be returning the wrong value on subsequent
calls. Diagnose the problem and fix the function's definition so that it returns
the correct value each time.
