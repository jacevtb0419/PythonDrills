# 34.2) Appending String Things

The following lines of code are supposed to add elements to a list, one at a
time. However, they do not seem to work correctly. Fix each line so that all
elements are able to be appended one at a time.
