things = []
things.append("Dogs")
things.append("Cups")
things.append("Cards")
things.append("Petals")
print(things)
