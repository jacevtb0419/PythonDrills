message = "THE RENT IS TOO HIGH!"
message = message.lower()
print(message)
