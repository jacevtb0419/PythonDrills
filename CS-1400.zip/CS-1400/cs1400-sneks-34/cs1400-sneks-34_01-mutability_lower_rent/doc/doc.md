# 34.1) Lower Rent

The message in the given program is shouting too loudly, and the author wants to
have it quieter (by making it lowercase). However, their solution doesn't seem
to be working. Without adjusting the original string literal, fix the way the
.lower() method is used so that variable's value is correctly changed to
lowercase.
