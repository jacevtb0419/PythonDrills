a = round(float("9.50"))
print(a)