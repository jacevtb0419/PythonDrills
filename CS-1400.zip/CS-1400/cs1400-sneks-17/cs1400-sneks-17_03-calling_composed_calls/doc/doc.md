# 17.3) Double Function Calls

The function `float` consumes a string
and converts it to a float. Print the
string `"9.50"` as a whole number. Use
the `round` function and the `float`
function together and assign the result
to a variable. Then, `print` the value
assigned to the variable.

Here is an example of using the `float` function:

```python
price = float("13.99")
```
