# 17.2) Functions Calls and Variables

This time, call the `round` function again with `9.50` but instead of
immediately printing the result of rounding 9.50, now assign the result to a
variable. Then print that variable.
