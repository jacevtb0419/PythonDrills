a = round(9.50) 
print(a)