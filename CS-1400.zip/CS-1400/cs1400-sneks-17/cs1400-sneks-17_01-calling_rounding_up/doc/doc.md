# 17.1) Rounding Up

The function `round` consumes a number (as a `float`) and returns it rounded to
the nearest whole number. You are buying some food and want to know roughly how
much it will cost. Use the round function to round $`9.50` to the nearest whole
number and print the result.
