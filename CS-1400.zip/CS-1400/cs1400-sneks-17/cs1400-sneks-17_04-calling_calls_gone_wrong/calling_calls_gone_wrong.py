print("Whatever could be wrong?")
