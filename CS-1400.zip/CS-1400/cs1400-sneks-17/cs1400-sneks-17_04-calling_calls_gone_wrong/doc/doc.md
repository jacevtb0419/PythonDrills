# 17.4) Calls Gone Wrong!

The function call in the given program has a problem. Run the program to see the
error, then fix it so that the print function is called correctly.
