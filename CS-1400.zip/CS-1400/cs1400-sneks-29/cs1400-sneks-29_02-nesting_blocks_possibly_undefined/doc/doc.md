# 29.2) Possibly Undefined

The function `calculate_income` in the given program is broken. Fix the function
so that it will correctly decrease the passed-in salary by 10% but only if the
salary is greater than $5,000 per year. Otherwise, it should return the salary
un-adjusted.
