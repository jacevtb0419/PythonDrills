# 29.4) Stay Positive

Create a function named `add_positives` that consumes two numbers and returns
their sum. However, this function should only add positive numbers. Therefore,
if either number is less than zero, you should instead return `0`. Make sure to
unit test your function.
