print("Welcome to CodeGrinder!")
