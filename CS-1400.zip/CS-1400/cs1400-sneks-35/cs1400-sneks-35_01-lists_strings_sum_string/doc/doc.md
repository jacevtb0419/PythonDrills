# 35.1) Sum String

The given program is meant to sum a list of comma-separated numbers in a string.
Read through it so that you know what is going on, then try to fix it to
correctly sum and print the values.
