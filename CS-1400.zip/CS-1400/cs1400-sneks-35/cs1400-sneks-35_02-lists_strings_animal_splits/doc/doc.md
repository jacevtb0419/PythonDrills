# 35.2) Animal Splits

Write a function called `all_cats` that consumes a comma-separated string of
animals and returns whether *all* of the animals have "cat" in their name. For
example, the string "gerbil,catfish,dog,cat" would return False, but
"cat,catfish" would return True. If the function consumes an empty string, then
it returns False. Unit test this function.
