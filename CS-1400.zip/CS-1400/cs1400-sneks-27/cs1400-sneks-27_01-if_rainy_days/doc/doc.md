# 27.1) Rainy Days

Use an `if` statement to capture the following logic:

If the precipitation is greater than 50%,
print "It will probably rain."
Otherwise,
print "It might not rain."

Set the value of precipitation to the current chance of precipitation tomorrow
by replacing the ? with the percent chance of rain (without the percent sign).
If for some reason you don't know the chance of precipitation tomorrow, try
Googling: "chance of precipitation tomorrow".
