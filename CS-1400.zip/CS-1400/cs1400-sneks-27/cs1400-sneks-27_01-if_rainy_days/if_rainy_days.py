precipitation = 0
if precipitation > .5:
    print("It will probably rain.")
else:
    print("It might not rain.")
