# Remember to initialize the variables!

age = 22
has_license = True

# Keep this If/else structure unchanged, but
# fill in the blanks
if has_license: 
    if age >= 21:
        if age < 1000:
            print("Can rent a car")
        else:
            print("Too old")
    else:
       print("Too young")
else:
    print("Doesn't have a license")

# Conditions




# Prints




