# 32.3) Temperature Conversion

The list of temperatures below are in Celsius. Use the following formula to
convert and print each value, using a `for` loop.

    Fahrenheit = Celsius * 9 / 5 + 32
