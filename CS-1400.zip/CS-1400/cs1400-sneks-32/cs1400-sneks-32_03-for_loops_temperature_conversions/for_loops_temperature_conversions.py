
temperatures = [10, 20, 5]
for Celsius in temperatures:
    Fahrenheit = Celsius * 9 / 5 + 32
    print(Fahrenheit)