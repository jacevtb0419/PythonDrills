credits = [3, 3, 3, 1]
for credit_hours in credits:
    print(credit_hours)