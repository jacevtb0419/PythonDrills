# 32.2) To Your Credit

Use a list to represent the courses you are taking by the number of credits they
are worth. For instance, this course is worth `3` credits, so your list will
have at least one number in it. Then, print out each credit value using a `for`
loop.
