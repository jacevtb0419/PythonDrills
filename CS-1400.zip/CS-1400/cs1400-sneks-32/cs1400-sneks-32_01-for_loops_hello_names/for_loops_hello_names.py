names = ["Harry", "Hermione", "Ron"]
for name in names:
    message = "Hello " + name
    print(message)
