# 32.1) Hello Names

The `for` loop in the given program is meant to print out each value of the list
with a message. However, the lines of code are out of order. Correct the order
of the lines and fix any indentation.
