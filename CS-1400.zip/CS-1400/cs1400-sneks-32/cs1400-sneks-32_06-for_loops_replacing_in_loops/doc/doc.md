# 32.6) Replacing in Loops

Use the replace method on each of the filenames in the given list to turn the
dashes into spaces and print the updated filename.

Don't worry about writing a function, just loop over the list and perform the
operation on each filename.
