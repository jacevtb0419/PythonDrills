# 15.6) A String of Stuff

Define a variable with a string value that includes a number, a letter, and a
symbol. Then, print this value.
