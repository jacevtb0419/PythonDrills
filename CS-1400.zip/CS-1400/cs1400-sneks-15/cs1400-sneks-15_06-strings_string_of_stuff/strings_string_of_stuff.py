a = "a1!"
print(a)