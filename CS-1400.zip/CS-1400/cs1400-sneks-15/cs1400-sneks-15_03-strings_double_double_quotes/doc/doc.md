# 15.3) Double Double Quotes

Print the following string. However, you may not use single quotes ('). Instead,
you should properly escape the quotes inside of the string.

Then the student asked, "But how do I escape a string?"
