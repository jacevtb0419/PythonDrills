# 15.5) Ints and Strs

Define two variables (their names are up to you): the first variable should have
the integer value 5, and the second should have the string value "5". Print each
value on a separate line and observe the output.
