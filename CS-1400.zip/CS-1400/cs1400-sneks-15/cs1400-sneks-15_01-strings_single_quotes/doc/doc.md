# 15.1) Single Quotes

Print the following literal string value (the entire line):

Mrs. Flaversham said, "How are you today?"
