# 15.2) Double Quotes

Print the following line as a literal string value:

The dog's house is big and red.
