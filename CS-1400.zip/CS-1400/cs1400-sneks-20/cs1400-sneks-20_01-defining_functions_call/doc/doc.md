# 20.1) A Defining Call

The function in the given program calculates the average of two numbers.
However, it is not being used correctly. Modify the program so that it runs
correctly.

Note: You should not need to modify the function definition, only the function
call.
