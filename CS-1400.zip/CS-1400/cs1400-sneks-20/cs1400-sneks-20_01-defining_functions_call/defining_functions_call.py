def average_numbers(first, second):
    return (first+second)/2

print(average_numbers(2, 8))