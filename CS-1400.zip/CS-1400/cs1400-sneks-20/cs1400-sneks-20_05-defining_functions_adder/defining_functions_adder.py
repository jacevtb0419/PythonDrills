def add_together(number1, number2):
    return number1 + number2  

print(add_together(3, 4))