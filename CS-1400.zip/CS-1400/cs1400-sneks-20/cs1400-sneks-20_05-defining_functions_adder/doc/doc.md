# 20.5) Adder

Write a function `add_together` that consumes two integer parameters and returns
their sum. Call the function once, and then print the result.
