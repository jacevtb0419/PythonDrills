# 20.3) Getting Old

Write a function named `get_my_age` that returns your age as an integer (this is
YOUR age, so if you were 21 you would return the number 21). Note that this
function takes no arguments and no input from the user. Call the function once
and print the result.

Reflect on the difference between creating a variable with a constant value and
creating a function with no arguments that returns a constant return value.
