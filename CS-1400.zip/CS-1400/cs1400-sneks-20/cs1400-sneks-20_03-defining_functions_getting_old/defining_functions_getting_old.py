def get_my_age():
    age = 22
    return age 

print(get_my_age())