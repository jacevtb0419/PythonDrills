# 20.2) A Do Nothing Function

Define a function named `do_nothing` that has no parameters, no return values,
and does absolutely nothing. Call this function and print the result.
