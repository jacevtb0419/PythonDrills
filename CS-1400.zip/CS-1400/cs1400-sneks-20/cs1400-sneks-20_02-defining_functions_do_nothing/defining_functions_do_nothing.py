def do_nothing():
    pass
print(do_nothing())