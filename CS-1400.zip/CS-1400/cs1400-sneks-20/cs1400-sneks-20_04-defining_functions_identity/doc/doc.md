# 20.4) Identity

Write a function called "`identity`" that consumes a number and returns that number,
unmodified. This basic function (that accomplishes nothing) is known as the
"identity function", because it leaves the parameter's identity unchanged. Call
this function once and print the result.

For those who might have programmed using another language before, remember that
you do not indicate a parameter's type in Python. Even though the instructions
say that function consumes a number, you do not indicate this in the function
definition.
