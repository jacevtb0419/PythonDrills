def identity(number):
    return number

print(identity(5))