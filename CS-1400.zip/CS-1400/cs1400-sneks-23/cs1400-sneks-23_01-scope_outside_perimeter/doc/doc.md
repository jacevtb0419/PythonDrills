# 23.1) Outside the Perimeter

The function `calculate_perimeter` is meant to return the length of the outline
of a rectangle by consuming its `width` and `height`. The given program is meant
to call the function for a rectangle with the dimensions 4 x 3 and then unit
test the result. However, the function is not passing the test. Fix it to
properly enable data to flow in and out of the function and pass its unit test.
