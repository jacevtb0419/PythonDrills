# 23.2) Weekend Off

The function `cut_day` is supposed to consume nothing but take in the current
day of the week as user input, then produce the current day without the
`"day"` part at the end (e.g., `"Thursday"` becomes `"Thurs"`). However, it does
not work correctly. Fix this function by applying the rules of scope.

Don't worry about writing any unit tests for this drill.
