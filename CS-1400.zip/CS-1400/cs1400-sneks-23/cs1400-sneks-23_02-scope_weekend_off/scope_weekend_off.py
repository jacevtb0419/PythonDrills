
def cut_day():
    day_of_week = input("What day of the week is today?")
    return day_of_week[:-3]

print(cut_day())
