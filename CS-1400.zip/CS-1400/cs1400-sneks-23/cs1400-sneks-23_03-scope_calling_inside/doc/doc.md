# 23.3) Calling Inside Definitions

The function `combine_message` in the given program will consume three messages
and combine them into one. It is supposed to use the `improve_message` function
to also improve the messages before returning them. Fix the body of the
`combine_message` function so that it correctly calls the `improve_message`
function.

Hint: Only change the body of the `combine_messages` function; you shouldn't
change any other code in the program.
