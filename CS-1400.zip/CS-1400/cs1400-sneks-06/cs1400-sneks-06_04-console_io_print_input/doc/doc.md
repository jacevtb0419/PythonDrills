# 6.4) Print Input

The `input` function retrieves input from the user. Note that it *evaluates* to
whatever the user types.

The given program `console_io_print_input.py` asks the user to type something.
Modify the expression in the program such that it will *print* whatever the user
types. For this exercise, your solution should only contain a single line of
code. Hint: try to do it without using a variable, we'll get to that in a later
assignment.

If you need to go back to the original program, select "Reset to beginning of
current step..." in the Codegrinder menu. Then, reopen your file and it will
load the file contents originally downloaded from CodeGrinder.
