print(input("Type something, please: "))
