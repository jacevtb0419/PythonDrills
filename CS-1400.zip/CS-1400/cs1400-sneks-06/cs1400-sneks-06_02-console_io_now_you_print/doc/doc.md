# 6.2) Now You Print

Now you will write your own Python statement. Call the `print` function and
include in the parenthesis a **string literal** for the phrase "Hello World".

Test your program. Once you know that it runs correctly, submit your program to
CodeGrinder.
