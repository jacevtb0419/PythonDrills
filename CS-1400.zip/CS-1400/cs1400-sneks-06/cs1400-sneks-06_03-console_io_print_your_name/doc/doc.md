# 6.3) Print Your Name

This time, print your name. We won't check that you've printed your actual name,
so feel free to print something else instead!
